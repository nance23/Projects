# csci141-p1-nance23
csci141-p1-nance23 created by GitHub Classroom
a program that calculates potential savings when you switch driving from a gasoline-powered car to an electric vehicle (EV). 
